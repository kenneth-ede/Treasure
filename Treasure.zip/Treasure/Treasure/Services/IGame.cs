﻿using Treasure.Models;

namespace Treasure.Services
{
    public interface IGame
    {
        List<Player> GetPlayers();
        void Start();
    }
}