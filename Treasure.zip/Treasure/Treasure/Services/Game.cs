﻿using Microsoft.Extensions.Options;
using Treasure.Extensions;
using Treasure.Factories;
using Treasure.Models;
using Treasure.Options;
using static Treasure.Models.Enums;

namespace Treasure.Services
{
    public class Game : IGame
    {
        private readonly GameOptions _options;
        private List<Chest> _chests;
        private List<Trap> _traps;

        public Game(IOptions<GameOptions> options)
        {
            _options = options.Value;
            _chests = new List<Chest>();
            _traps = new List<Trap>();
        }

        public void Start()
        {
            var board = new Board(_options.Rows, _options.Columns);

            var players = GetPlayers();

            _chests = GetChests();

            var winner = false;

            while (players.Where(x => x.IsAlive).Count() == 2 && !winner)
                foreach (var player in players.Where(X => X.IsAlive))
                {
                    winner = PlayerTurn(player, board);

                    if (winner)
                    {
                        Console.WriteLine(string.Format(FormatStrings.Winner, player.Name));
                        break;
                    }

                    if (!player.IsAlive)
                    {
                        Console.WriteLine(string.Format(FormatStrings.Dead, player.Name));
                        break;
                    }
                }
        }

        public bool PlayerTurn(Player player, Board board)
        {
            var direction = GetDirection(player);

            if (direction == Direction.LayTrap && player.Traps > 0)
            {
                TryLayTrap(player, board);
                return false;
            }
            else
            {
                var result = player.ApplyAction(direction, board);

                Console.WriteLine(result + Environment.NewLine);

                if (result == Result.OK)
                {
                    var chest = _chests.GetChestForCoordinates(player.Coordinates);

                    if (chest != null)
                    {
                        player.AddChest(chest);

                        _chests.Remove(chest);

                        Console.WriteLine(string.Format(FormatStrings.ChestFound, player.Name, player.Chests.Count) + Environment.NewLine);

                        return player.Chests.Count > _options.TreasureChests / 2;
                    }
                }
                else
                    return false;

                var trap = _traps.GetTrapForCoordinates(player.Coordinates);

                if (trap != null)
                {
                    player.IsAlive = false;
                    Console.WriteLine(String.Format(FormatStrings.Boom, player.Name) + Environment.NewLine);
                }
            }

            return false;
        }

        public void TryLayTrap(Player player, Board board)
        {
            var message = string.Empty;

            if (player.Traps <= 0)
                message = Result.OutOfTraps;
            else
            {
                var coords = player.GetSquareFacingCoordinates(board);

                if (coords != null)
                {
                    if (!_chests.ContainsCoordinates(coords) && !_traps.ContainsCoordinates(coords))
                    {
                        _traps.Add(new Trap { Coordinates = coords });
                        player.TakeTrap();
                        Console.WriteLine(Result.TrapLaid);
                    }
                    else
                    {
                        message = Result.Occupied;
                    }
                }
                else
                {
                    message = String.Format(FormatStrings.OverEdge, player.Name);
                }
            }

            Console.WriteLine(message + Environment.NewLine);
        }

        public List<Chest> GetChests()
        {
            var chests = new List<Chest>();

            for (var i = 0; i < _options.TreasureChests; i++)
                chests.Add(new Chest(CoordinateFactory.Create(_options.Rows, _options.Columns)));

            return chests;
        }

        public List<Player> GetPlayers()
        {
            var players = new List<Player>();

            for (int i = 0; i < 2; i++)
            {
                Console.Write(String.Format(FormatStrings.PlayerPrompt, i));
                var name = Console.ReadLine();
                players.Add(new Player(name, _options.TrapsPerPlayer, CoordinateFactory.Create(_options.Rows, _options.Columns)));
            }

            return players;
        }

        public Direction GetDirection(Player player)
        {
            var act = Direction.None;

            while (act == Direction.None)
            {
                Console.WriteLine(String.Format(FormatStrings.Next, player.Name, player.Facing, player.Coordinates));
                var key = Console.ReadKey();
               
                act = key.Key switch
                {
                    ConsoleKey.LeftArrow => Direction.TurnLeft,
                    ConsoleKey.RightArrow => Direction.TurnRight,
                    ConsoleKey.UpArrow => Direction.Forward,
                    ConsoleKey.DownArrow => Direction.LayTrap,
                    _ => Direction.None
                };

            }

            return act;
        }
    }
}
