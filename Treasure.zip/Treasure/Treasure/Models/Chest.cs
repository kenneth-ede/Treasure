﻿namespace Treasure.Models
{
    public class Chest
    {
        public Chest(Coordinates coordinates)
        {
            Coordinates = coordinates;
        }

        public Coordinates Coordinates { get; private set; }
    }
}
