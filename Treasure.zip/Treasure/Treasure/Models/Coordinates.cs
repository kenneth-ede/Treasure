﻿namespace Treasure.Models
{
    public class Coordinates : IEquatable<Coordinates>
    {
        public int X { get; set; }
        public int Y { get; set; }

        public bool Equals(Coordinates? other)
        {
            return other?.X == X && other?.Y == Y;
        }

        public override int GetHashCode()
        {
            return X.GetHashCode() + Y.GetHashCode();
        }

        public override string ToString()
        {
            return $"{X},{Y}";
        }
    }
}
