﻿using static Treasure.Models.Enums;

namespace Treasure.Models
{
    public class Player
    {
        public bool IsAlive { get; set; } = true;
        public string Name { get; private set; }
        public Facing Facing { get; set; }
        public List<Chest> Chests { get; private set; }
        public int Traps { get; private set; }
        public Coordinates Coordinates { get; private set; }

        public Player(string name, int traps, Coordinates coordinates)
        {
            Name = name;
            Chests = new List<Chest>();
            Traps = traps;
            Coordinates = coordinates;
        }

        public int AddChest(Chest chest)
        {
            Chests.Add(chest);
            return Chests.Count;
        }

        public int TakeTrap()
        {
            return --Traps;
        }
    }
}
