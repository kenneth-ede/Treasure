﻿namespace Treasure.Models
{
    public class Board
    {
        public Coordinates Bounds { get; set; }

        public List<Coordinates> Traps { get; set; }

        public Board(int rows, int columns)
        {
            Bounds = new Coordinates { X = rows, Y = columns };

            Traps = new List<Coordinates>();
        }

        public bool CoordinatesWithinBounds(int x, int y)
        {
            if (x < 0 || y < 0)
                return false;

            if (x > Bounds.X || y > Bounds.Y)
                return false;

            return true;
        }
    }
}
