﻿namespace Treasure.Models
{
    public static class Enums
    {
        public enum Direction
        {
            None,
            TurnLeft,
            TurnRight,
            Forward,
            LayTrap
        }

        public enum Facing
        {
            North,
            East,
            South,
            West
        }
    }
}
