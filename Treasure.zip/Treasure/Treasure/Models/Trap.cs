﻿namespace Treasure.Models
{
    public class Trap
    {
        public Coordinates Coordinates { get; set; }
    }
}
