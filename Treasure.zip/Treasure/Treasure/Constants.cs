﻿namespace Treasure
{
    public static class Result
    {
        public const string OK = "Ok";
        public const string OnEdge = "You're already on edge !";
        public const string Occupied = "Already occupied, but what could it be ?";
        public const string TrapLaid = "Trap laid";
        public const string End = "End of game";
        public const string OutOfTraps = "You are out of traps";
    }

    public static class FormatStrings
    {
        public const string Winner = "{0}, you have won!";
        public const string Dead = "{0} has killed him/her self.";
        public const string ChestFound = "Woo-hoo, {0} you've got one ! - you now have {1}";
        public const string Boom = "BOOM!!! Oh dear, bye {0}";
        public const string OverEdge = "{0}, you can't lay a trap over the edge.";
        public const string PlayerPrompt = "Player {0} name: ";
        public const string Next = "Player {0} facing {1} ({2}) - next action: ";
    }
}
