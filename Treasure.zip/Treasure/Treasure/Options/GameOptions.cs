﻿namespace Treasure.Options
{
    public class GameOptions
    {
        public int Rows { get; set; }
        public int Columns { get; set; }
        public int TreasureChests { get; set; }
        public int TrapsPerPlayer { get; set; }
    }
}
