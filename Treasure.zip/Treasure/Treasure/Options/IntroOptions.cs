﻿namespace Treasure.Options
{
    public class IntroOptions
    {
        public string Title { get; set; }
        public string Info { get; set; }
        public string Play1 { get; set; }
        public string Play2 { get; set; }
        public string Play3 { get; set; }
    }
}
