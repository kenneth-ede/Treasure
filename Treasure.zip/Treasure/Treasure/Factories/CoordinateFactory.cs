﻿using Treasure.Models;

namespace Treasure.Factories
{
    public static class CoordinateFactory
    {
        private static List<Coordinates> Used = new List<Coordinates>();

        public static Coordinates Create(int maxRow, int maxColumn)
        {
            var rand = new Random();

            Coordinates coords = null;

            var ok = false;

            while (!ok)
            {
                coords = new Coordinates { X = rand.Next(0, maxRow), Y = rand.Next(0, maxColumn) };
                if (!Used.Contains(coords))
                {
                    Used.Add(coords);
                    ok = true;
                }
            }

            return coords;
        }
    }
}
