﻿using Treasure.Models;

namespace Treasure.Extensions
{
    public static class ChestExtensions
    {
        public static bool ContainsCoordinates(this List<Chest> chests, Coordinates coordinates)
        {
            return chests.Any(x => x.Coordinates.X == coordinates.X && x.Coordinates.Y == coordinates.Y);
        }

        public static Chest? GetChestForCoordinates(this List<Chest> chests, Coordinates coordinates)
        {
            return chests.Where(x => x.Coordinates.X == coordinates.X && x.Coordinates.Y == coordinates.Y).FirstOrDefault();
        }
    }
}
