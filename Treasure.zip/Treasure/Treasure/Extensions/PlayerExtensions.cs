﻿using Treasure.Models;
using static Treasure.Models.Enums;

namespace Treasure.Extensions
{
    public static class PlayerExtensions
    {
        public static Coordinates? GetSquareFacingCoordinates(this Player player, Board board)
        {
            var coords = player.Facing switch
            {
                Facing.North => new Coordinates { X = player.Coordinates.X, Y = player.Coordinates.Y + 1 },
                Facing.South => new Coordinates { X = player.Coordinates.X, Y = player.Coordinates.Y - 1 },
                Facing.East => new Coordinates { X = player.Coordinates.X + 1, Y = player.Coordinates.Y },
                Facing.West => new Coordinates { X = player.Coordinates.X - 1, Y = player.Coordinates.Y },
                _ => null
            };

            if (board.CoordinatesWithinBounds(coords.X, coords.Y))
                return coords;

            return null;
        }

        public static string ApplyAction(this Player player, Direction direction, Board board)
        {
            var message = Result.OK;

            if (direction == Direction.TurnRight)
            {
                player.Facing = player.Facing switch
                {
                    Facing.North => Facing.East,
                    Facing.East => Facing.South,
                    Facing.South => Facing.West,
                    Facing.West => Facing.North,
                    _ => player.Facing
                };
            }
            else if (direction == Direction.TurnLeft)
            {
                player.Facing = player.Facing switch
                {
                    Facing.North => Facing.West,
                    Facing.West => Facing.South,
                    Facing.South => Facing.East,
                    Facing.East => Facing.North,
                    _ => player.Facing
                };
            }
            else if (direction == Direction.Forward)
            {
                if (player.Facing == Facing.North)
                    if (player.Coordinates.Y < board.Bounds.Y)
                        player.Coordinates.Y++;
                    else
                        message = Result.OnEdge;
                else if (player.Facing == Facing.South)
                    if (player.Coordinates.Y > 0)
                        player.Coordinates.Y--;
                    else
                        message = Result.OnEdge;
                else if (player.Facing == Facing.East)
                    if (player.Coordinates.X < board.Bounds.X)
                        player.Coordinates.X++;
                    else
                        message = Result.OnEdge;
                else if (player.Facing == Facing.West)
                    if (player.Coordinates.X > 0)
                        player.Coordinates.X--;
                    else
                        message = Result.OnEdge;
            }

            return message;
        }
    }
}
