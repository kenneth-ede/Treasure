﻿using Treasure.Models;

namespace Treasure.Extensions
{
    public static class TrapExtensions
    {
        public static bool ContainsCoordinates(this List<Trap> traps, Coordinates coordinates)
        {
            return traps.Any(x => x.Coordinates.X == coordinates.X && x.Coordinates.Y == coordinates.Y);
        }

        public static Trap? GetTrapForCoordinates(this List<Trap> traps, Coordinates coordinates)
        {
            return traps.Where(x => x.Coordinates.X == coordinates.X && x.Coordinates.Y == coordinates.Y).FirstOrDefault();
        }
    }
}
