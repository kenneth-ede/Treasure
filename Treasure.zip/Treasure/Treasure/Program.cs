﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Treasure.Options;
using Treasure.Services;

class Program
{
    static async Task Main(string[] args)
    {
        var host = BuildHost(args);

        if (!DisplayHeader(host))
        {
            Console.WriteLine("Could not read appsettings.json");
            return;
        }

        var game = host.Services.GetRequiredService<IGame>();

        game.Start();
    }

    private static IHost BuildHost(string[] args)
    {

        IHost host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((hostContext, services) =>
            {
                services.Configure<GameOptions>(hostContext.Configuration.GetSection("Game"));
                services.Configure<IntroOptions>(hostContext.Configuration.GetSection("Intro"));
                services.AddSingleton<IGame, Game>();
            })
            .Build();

        return host;
    }

    private static bool DisplayHeader(IHost host)
    {
        var game = host.Services.GetRequiredService<IOptions<GameOptions>>()?.Value;
        var intro = host.Services.GetRequiredService<IOptions<IntroOptions>>()?.Value;

        if (game == null || intro == null)
            return false;

        Console.WriteLine($"{intro.Title}{Environment.NewLine}{Environment.NewLine}");
        Console.WriteLine(string.Format(intro.Info, game.TreasureChests, game.Rows, game.Columns) + Environment.NewLine);
        Console.WriteLine("Players each take turn to perform 1 of four actions using the arrow keys ..." + Environment.NewLine);
        Console.WriteLine($"\tTurn left (left arrow){Environment.NewLine}\tTurn right (right arrow){ Environment.NewLine}\tStep ahead (up arrow) { Environment.NewLine}\tLay a trap! (down arrow){ Environment.NewLine}");
        Console.WriteLine("If you step on a treasure, it's yours; if you step on a trap, you're dead." + Environment.NewLine);
        Console.WriteLine("Whoever collects the most treasure chests wins. Good luck ..." + Environment.NewLine);

        return true;
    }
}
